```
./build_conda.sh 3.9 1.11.0 cu113  # python, pytorch and cuda version
```
